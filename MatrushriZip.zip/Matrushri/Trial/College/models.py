from django.db import models


class Management(models.Model):
    name = models.CharField(max_length=300)
    image = models.ImageField(null=True, blank=True,
                              upload_to='management_profile/')
    designation = models.CharField(max_length=300)
    about = models.TextField()

    def __str__(self):
        return self.name


class HelpingHands(models.Model):
    title = models.CharField(max_length=300, default="VPPCOE")
    image_box = models.ImageField(
        null=True, blank=True, upload_to='image_boxes/')

    def __str__(self):
        return self.title

# model for companies links


class Company(models.Model):
    name = models.CharField(max_length=100)
    website = models.URLField()

    def __str__(self):
        return self.name

from django.contrib import admin
from .models import Management, HelpingHands, Company


admin.site.register(Management)
admin.site.register(HelpingHands)
admin.site.register(Company)


# Register your models here.

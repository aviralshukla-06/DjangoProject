from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path("", views.main, name="College-main"),
    path("home/", views.home, name="College-home"),
    path("about/", views.about, name="College-about"),
    path("contact/", views.contact, name="College-contact"),

]

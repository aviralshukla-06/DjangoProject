
from django.http import HttpResponse
from django.template import loader
from .models import Management, HelpingHands, Company
from django.contrib.auth.decorators import login_required


def main(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())


def home(request):
    team = Management.objects.all().values()
    helping_hands = HelpingHands.objects.all()
    template = loader.get_template('home.html')
    context = {
        'team': team,
        'helping_hands': helping_hands
    }
    return HttpResponse(template.render(context, request))


@login_required(login_url="login")
def about(request):
    companies = Company.objects.all()
    template = loader.get_template('about.html')
    context = {
        'companies': companies
    }
    return HttpResponse(template.render(context, request))


def contact(request):
    template = loader.get_template('contact.html')
    return HttpResponse(template.render())
